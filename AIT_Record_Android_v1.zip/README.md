# AIT Record — Android App v1

یہ ابتدائی Android project ہے۔ اس میں:
- Dashboard: بقایا، وصول، Total Semen/AI
- فارم Search
- نیا فارم/AI ریکارڈ
- گائے کی تصویر منتخب کرنا
- AI/Delivery تاریخ
- کل/وصول/بقایا رقم
- WhatsApp اور SMS
- JSON Backup/Restore
- میسج: "AIT عمر حیات پر اعتماد کا شکریہ" اور 03017962013

## APK بنانے کا طریقہ
Android Studio میں یہ project کھولیں، Gradle sync کریں، پھر:
Build > Build APK(s)

اہم: اس ورژن میں Backup/Restore دستی فائل کے ذریعے ہے۔ Cloud automatic backup اگلے مرحلے میں Firebase/Google account کے ساتھ شامل کیا جا سکتا ہے۔
