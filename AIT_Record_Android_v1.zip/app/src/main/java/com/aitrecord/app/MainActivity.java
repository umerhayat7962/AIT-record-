package com.aitrecord.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, list;
    SharedPreferences sp;
    JSONArray records = new JSONArray();
    final int PICK_IMAGE = 10, SAVE_BACKUP = 11, OPEN_BACKUP = 12;
    String pendingImage = "";

    int dp(float n){ return (int)(n*getResources().getDisplayMetrics().density+0.5f); }
    TextView tv(String s, float size, int color){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setPadding(dp(10),dp(8),dp(10),dp(8)); t.setGravity(Gravity.CENTER_VERTICAL|Gravity.RIGHT);
        return t;
    }
    Button btn(String s){
        Button b=new Button(this); b.setText(s); b.setTextSize(14); b.setAllCaps(false);
        b.setPadding(dp(8),dp(4),dp(8),dp(4)); return b;
    }
    EditText input(String hint){
        EditText e=new EditText(this); e.setHint(hint); e.setTextSize(15); e.setGravity(Gravity.RIGHT);
        e.setSingleLine(true); e.setPadding(dp(12),dp(8),dp(12),dp(8));
        return e;
    }

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        sp=getSharedPreferences("ait_record",MODE_PRIVATE);
        load();
        dashboard();
    }

    void load(){
        try { records=new JSONArray(sp.getString("records","[]")); }
        catch(Exception e){ records=new JSONArray(); }
    }
    void save(){ sp.edit().putString("records",records.toString()).apply(); }

    void base(String title){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(247,249,248)); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout bar=new LinearLayout(this); bar.setGravity(Gravity.CENTER_VERTICAL); bar.setPadding(dp(8),0,dp(8),0);
        bar.setBackgroundColor(Color.rgb(8,122,62));
        TextView t=tv(title,21,Color.WHITE); t.setTypeface(null,1);
        bar.addView(t,new LinearLayout.LayoutParams(0,dp(60),1));
        Button back=btn("☰"); back.setTextColor(Color.WHITE); back.setBackgroundColor(Color.TRANSPARENT);
        back.setOnClickListener(v->dashboard());
        bar.addView(back,new LinearLayout.LayoutParams(dp(60),dp(60)));
        root.addView(bar);
        ScrollView sv=new ScrollView(this); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(dp(12),dp(12),dp(12),dp(80));
        sv.addView(list); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
    }

    TextView card(String title,String value,int color){
        TextView c=tv(title+"\n"+value,18,color); c.setGravity(Gravity.CENTER);
        c.setBackgroundColor(Color.WHITE); c.setPadding(dp(6),dp(14),dp(6),dp(14));
        c.setTypeface(null,1); return c;
    }

    void dashboard(){
        base("AIT RECORD\nعمر حیات");
        int received=0, due=0, ai=records.length();
        for(int i=0;i<records.length();i++) try{
            JSONObject o=records.getJSONObject(i);
            received+=o.optInt("received",0); due+=o.optInt("due",0);
        }catch(Exception ignored){}
        LinearLayout cards=new LinearLayout(this); cards.setGravity(Gravity.CENTER); cards.setWeightSum(3);
        cards.addView(card("بقایا رقم","Rs. "+due,Color.rgb(198,40,40)),new LinearLayout.LayoutParams(0,dp(110),1));
        cards.addView(card("وصول رقم","Rs. "+received,Color.rgb(8,122,62)),new LinearLayout.LayoutParams(0,dp(110),1));
        cards.addView(card("Total Semen / AI",""+ai,Color.rgb(21,101,192)),new LinearLayout.LayoutParams(0,dp(110),1));
        list.addView(cards);
        LinearLayout actions=new LinearLayout(this); actions.setGravity(Gravity.CENTER);
        Button add=btn("＋ نیا فارم شامل کریں"); add.setOnClickListener(v->addRecord());
        Button search=btn("🔍 فارم تلاش کریں"); search.setOnClickListener(v->search());
        actions.addView(add,new LinearLayout.LayoutParams(0,dp(58),1)); actions.addView(search,new LinearLayout.LayoutParams(0,dp(58),1));
        list.addView(actions);
        Button backup=btn("☁️ Backup / Restore"); backup.setOnClickListener(v->backupMenu());
        list.addView(backup);
        list.addView(tv("تازہ ریکارڈ",19,Color.rgb(30,30,30)));
        showRecords("");
    }

    void showRecords(String q){
        for(int i=list.getChildCount()-1;i>=4;i--) list.removeViewAt(i);
        for(int i=records.length()-1;i>=0;i--) try{
            JSONObject o=records.getJSONObject(i);
            String hay=(o.optString("farm")+" "+o.optString("owner")+" "+o.optString("phone")+" "+o.optString("cow")+" "+o.optString("semen")).toLowerCase();
            if(!q.isEmpty() && !hay.contains(q.toLowerCase())) continue;
            LinearLayout row=new LinearLayout(this); row.setPadding(dp(4),dp(8),dp(4),dp(8)); row.setBackgroundColor(Color.WHITE);
            row.setGravity(Gravity.CENTER_VERTICAL);
            TextView info=tv("فارم: "+o.optString("farm")+"\nموبائل: "+o.optString("phone")+"\nگائے: "+o.optString("cow")+"\nSemen: "+o.optString("semen")+"\nAI: "+o.optString("ai")+"\nDelivery: "+o.optString("delivery")+"\nبقایا: Rs. "+o.optInt("due",0),15,Color.DKGRAY);
            row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
            Button wa=btn("WhatsApp"); wa.setOnClickListener(v->sendWhatsApp(o)); row.addView(wa);
            Button sms=btn("SMS"); sms.setOnClickListener(v->sendSms(o)); row.addView(sms);
            list.addView(row);
            View sep=new View(this); sep.setBackgroundColor(Color.LTGRAY); list.addView(sep,new LinearLayout.LayoutParams(-1,dp(1)));
        }catch(Exception ignored){}
    }

    void search(){
        final EditText e=input("فارم کا نام / موبائل / گائے نمبر لکھیں");
        new AlertDialog.Builder(this).setTitle("فارم تلاش کریں").setView(e)
            .setPositiveButton("تلاش", (d,w)->{ dashboard(); showRecords(e.getText().toString().trim()); })
            .setNegativeButton("منسوخ",null).show();
    }

    void addRecord(){
        base("نیا ریکارڈ شامل کریں");
        EditText farm=input("فارم کا نام"); EditText owner=input("مالک کا نام"); EditText phone=input("موبائل نمبر");
        EditText address=input("ایڈریس"); EditText semen=input("Semen کا نام / Code"); EditText cow=input("گائے نمبر / نام");
        EditText ai=input("AI کی تاریخ (DD-MM-YYYY)"); EditText delivery=input("Delivery تاریخ (DD-MM-YYYY)");
        EditText total=input("کل رقم"); EditText received=input("وصول رقم");
        Button photo=btn("📷 گائے کی تصویر منتخب کریں");
        TextView photoName=tv("تصویر منتخب نہیں ہوئی",14,Color.GRAY);
        photo.setOnClickListener(v->{ Intent in=new Intent(Intent.ACTION_OPEN_DOCUMENT); in.setType("image/*"); in.addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(in,PICK_IMAGE); });
        list.addView(farm); list.addView(owner); list.addView(phone); list.addView(address); list.addView(semen); list.addView(cow);
        list.addView(ai); list.addView(delivery); list.addView(photo); list.addView(photoName); list.addView(total); list.addView(received);
        Button saveBtn=btn("💾 محفوظ کریں");
        saveBtn.setOnClickListener(v->{
            int t=parse(total.getText().toString()), r=parse(received.getText().toString()), d=Math.max(0,t-r);
            try{
                JSONObject o=new JSONObject(); o.put("farm",farm.getText().toString()); o.put("owner",owner.getText().toString());
                o.put("phone",phone.getText().toString()); o.put("address",address.getText().toString()); o.put("semen",semen.getText().toString());
                o.put("cow",cow.getText().toString()); o.put("ai",ai.getText().toString()); o.put("delivery",delivery.getText().toString());
                o.put("total",t); o.put("received",r); o.put("due",d); o.put("photo",pendingImage);
                records.put(o); save(); pendingImage=""; Toast.makeText(this,"ریکارڈ محفوظ ہو گیا",Toast.LENGTH_SHORT).show(); dashboard();
            }catch(Exception ex){ Toast.makeText(this,"ریکارڈ محفوظ نہیں ہوا",Toast.LENGTH_SHORT).show(); }
        });
        list.addView(saveBtn);
    }

    int parse(String s){ try{return Integer.parseInt(s.replace(",","").trim());}catch(Exception e){return 0;} }

    void sendWhatsApp(JSONObject o){
        String msg="AIT Record\nفارم: "+o.optString("farm")+"\nگائے نمبر: "+o.optString("cow")+
        "\nSemen: "+o.optString("semen")+"\nAI تاریخ: "+o.optString("ai")+
        "\nمتوقع Delivery: "+o.optString("delivery")+"\nکل رقم: Rs. "+o.optInt("total")+
        "\nوصول: Rs. "+o.optInt("received")+"\nبقایا: Rs. "+o.optInt("due")+
        "\n\nAIT عمر حیات پر اعتماد کا شکریہ\n📞 03017962013";
        try{
            Intent i=new Intent(Intent.ACTION_SEND); i.setType("text/plain"); i.setPackage("com.whatsapp");
            i.putExtra(Intent.EXTRA_TEXT,msg); startActivity(i);
        }catch(Exception e){ Toast.makeText(this,"WhatsApp انسٹال نہیں ہے",Toast.LENGTH_SHORT).show(); }
    }

    void sendSms(JSONObject o){
        String msg="AIT Record\nفارم: "+o.optString("farm")+"\nگائے: "+o.optString("cow")+
        "\nSemen: "+o.optString("semen")+"\nAI: "+o.optString("ai")+
        "\nDelivery: "+o.optString("delivery")+"\nبقایا: Rs. "+o.optInt("due")+
        "\n\nAIT عمر حیات پر اعتماد کا شکریہ\n03017962013";
        Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("sms:"+o.optString("phone")));
        i.putExtra("sms_body",msg); startActivity(i);
    }

    void backupMenu(){
        new AlertDialog.Builder(this).setTitle("Backup / Restore")
            .setItems(new String[]{"💾 Backup فائل بنائیں","📥 Backup واپس لائیں"},(d,w)->{
                if(w==0){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"AIT_Record_Backup.json");startActivityForResult(i,SAVE_BACKUP);}
                else {Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/json");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,OPEN_BACKUP);}
            }).show();
    }

    @Override protected void onActivityResult(int req,int res,Intent data){
        super.onActivityResult(req,res,data);
        if(res!=RESULT_OK||data==null)return;
        try{
            if(req==PICK_IMAGE){ pendingImage=data.getData().toString(); Toast.makeText(this,"تصویر منتخب ہو گئی",Toast.LENGTH_SHORT).show(); }
            else if(req==SAVE_BACKUP){
                OutputStream out=getContentResolver().openOutputStream(data.getData()); out.write(records.toString().getBytes("UTF-8")); out.close();
                Toast.makeText(this,"Backup محفوظ ہو گیا",Toast.LENGTH_SHORT).show();
            } else if(req==OPEN_BACKUP){
                InputStream in=getContentResolver().openInputStream(data.getData()); ByteArrayOutputStream b=new ByteArrayOutputStream();
                byte[] buf=new byte[4096]; int n; while((n=in.read(buf))>0)b.write(buf,0,n); in.close();
                records=new JSONArray(new String(b.toByteArray(),"UTF-8")); save(); dashboard();
                Toast.makeText(this,"Backup واپس آ گیا",Toast.LENGTH_SHORT).show();
            }
        }catch(Exception e){Toast.makeText(this,"Backup/فائل میں مسئلہ آیا",Toast.LENGTH_SHORT).show();}
    }
}
